const demo = [
 {id:"kobe171",sport:"Basketball",player:"Kobe Bryant",card:"1997-98 Topps #171",price:2.99,raw:7.5,psa10:285,velocity:24,centering:9.1,corners:8.9,edges:9,surface:8.9,img:"https://images.unsplash.com/photo-1546519638-68e109498ffc?w=500&q=80",why:"Very low entry price versus raw market with strong Kobe demand. Condition appears worth a closer look."},
 {id:"mj205",sport:"Basketball",player:"Michael Jordan",card:"1992-93 Topps #205",price:3.25,raw:4.5,psa10:220,velocity:30,centering:9,corners:8.8,edges:9,surface:8.8,img:"https://images.unsplash.com/photo-1518065896235-a4c93e088e7f?w=500&q=80",why:"Cheap Jordan base/inset-era card with strong collector demand. Buy only if the actual card is clean."},
 {id:"bradytc",sport:"Football",player:"Tom Brady",card:"2008 Topps Chrome TC121",price:12.5,raw:12.5,psa10:190,velocity:12,centering:8.7,corners:8.6,edges:8.8,surface:8.7,img:"https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=500&q=80",why:"Chrome Brady is attractive, but this price is roughly market. Better target below $10."},
 {id:"rodgers431",sport:"Football",player:"Aaron Rodgers",card:"2005 Topps #431 RC",price:40,raw:18,psa10:250,velocity:9,centering:8.8,corners:8.8,edges:8.8,surface:8.7,img:"https://images.unsplash.com/photo-1560089000-7433a4ebbd64?w=500&q=80",why:"Good card, bad price. Grade upside doesn't compensate for paying far above the raw market."},
 {id:"gretzky84",sport:"Hockey",player:"Wayne Gretzky",card:"1997-98 Pacific Crown Royale #84",price:8,raw:8,psa10:95,velocity:8,centering:9,corners:8.8,edges:9,surface:8.8,img:"https://images.unsplash.com/photo-1580748141549-71748dbe0eab?w=500&q=80",why:"Base Crown Royale is collectible, but the real hunt is for desirable parallels at the right price."}
];

let watchlist = JSON.parse(localStorage.getItem("cardhunt-watch")||"[]");

function score(c){
  const discount = Math.max(0, Math.min(100, ((c.raw-c.price)/Math.max(c.raw,1))*100));
  const condition = (c.centering+c.corners+c.edges+c.surface)/4*10;
  const demand = Math.min(100, 45 + Math.min(55,c.velocity*2));
  const gradeUpside = Math.min(100, Math.max(0, (c.psa10/Math.max(c.price,1)-2)*18));
  return Math.round(.30*discount + .20*demand + .20*c.centering*10 + .15*condition + .10*gradeUpside + .05*Math.min(100,c.velocity*5));
}
function verdict(s){return s>=80?"BUY":s>=60?"WATCH":"PASS"}
function render(list=demo){
 const q=document.querySelector("#query").value.toLowerCase(), sport=document.querySelector("#sport").value, max=+document.querySelector("#maxPrice").value, min=+document.querySelector("#minScore").value;
 const out=list.filter(c=>(!q || `${c.player} ${c.card}`.toLowerCase().includes(q))&&(sport==="All"||c.sport===sport)&&c.price<=max&&score(c)>=min).sort((a,b)=>score(b)-score(a));
 document.querySelector("#results").innerHTML=out.length?out.map(c=>cardHTML(c)).join(""):`<div class="empty-list card">No demo matches. Try widening your filters.</div>`;
}
function cardHTML(c){
 const s=score(c), v=verdict(s), cls=v.toLowerCase(), saved=watchlist.includes(c.id);
 return `<article class="deal card">
   <img class="thumb" src="${c.img}" alt="">
   <div>
    <h3>${c.player} — ${c.card}</h3>
    <div class="meta">${c.sport} • Visible condition estimate ${((c.centering+c.corners+c.edges+c.surface)/4).toFixed(1)}/10</div>
    <div class="prices"><div class="price"><b>$${c.price.toFixed(2)}</b><span>ASK</span></div><div class="price"><b>$${c.raw.toFixed(0)}</b><span>RAW MARKET</span></div><div class="price"><b>$${c.psa10.toFixed(0)}</b><span>PSA 10</span></div></div>
    <div class="actions"><button class="mini" onclick="saveCard('${c.id}')">${saved?"★ Saved":"☆ Watch"}</button><button class="mini" onclick="alert(${JSON.stringify(c.why)})">Why?</button></div>
   </div>
   <div class="score"><b>${s}</b><span class="badge ${cls}">${v}</span></div>
  </article>`;
}
function saveCard(id){if(watchlist.includes(id))watchlist=watchlist.filter(x=>x!==id);else watchlist.push(id);localStorage.setItem("cardhunt-watch",JSON.stringify(watchlist));render();renderWatch();}
function renderWatch(){const cards=demo.filter(c=>watchlist.includes(c.id));document.querySelector("#watchlist").innerHTML=cards.length?cards.map(c=>cardHTML(c)).join(""):`<div class="empty-list card">Your watchlist is empty.</div>`}
function bindPreview(id){document.querySelector("#"+id).addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const img=document.createElement("img");img.src=URL.createObjectURL(f);document.querySelector("#previews").appendChild(img);});}
function scan(){
 const c={price:+scanPrice.value,raw:+rawMarket.value,psa10:+psa10.value,velocity:+velocity.value,centering:+centering.value,corners:+corners.value,edges:+edges.value,surface:+surface.value};
 const s=score(c),v=verdict(s), cls=v.toLowerCase(), discount=Math.max(0,((c.raw-c.price)/Math.max(c.raw,1))*100);
 scanResult.className="card result-card";
 scanResult.innerHTML=`<p class="eyebrow">CARDHUNT RESULT</p><div class="big-score">${s}<small>/100</small></div><span class="badge ${cls}">${v}</span>
 <div class="metric-grid"><div class="metric"><span>Price vs raw market</span><b>${discount.toFixed(0)}% discount</b></div><div class="metric"><span>Visible condition</span><b>${((c.centering+c.corners+c.edges+c.surface)/4).toFixed(1)}/10</b></div><div class="metric"><span>PSA 10 upside</span><b>${c.psa10>=c.price*8?"Strong":"Moderate"}</b></div><div class="metric"><span>Sales velocity</span><b>${c.velocity}/month</b></div></div>
 <p class="fine">Prototype score only. A photo-based estimate cannot guarantee a PSA grade, and live market data is not connected in this demo.</p>`;
}
document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));t.classList.add("active");document.getElementById(t.dataset.tab).classList.add("active");if(t.dataset.tab==="watch")renderWatch();});
document.querySelector("#huntBtn").onclick=()=>render();
document.querySelector("#clearWatch").onclick=()=>{watchlist=[];localStorage.removeItem("cardhunt-watch");renderWatch();};
bindPreview("front");bindPreview("back");
document.querySelectorAll(".sliders input").forEach(x=>x.addEventListener("input",()=>document.querySelector("#"+x.id+"Out").textContent=Number(x.value).toFixed(1)));
document.querySelector("#scanBtn").onclick=scan;
render();renderWatch();