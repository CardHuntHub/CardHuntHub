# CardHunt AI — MVP prototype

This is a working, mobile-friendly prototype of the CardHunt concept.

## What works now
- Deal-hunting dashboard
- Filters by sport, player/card, max price and score
- BUY / WATCH / PASS scoring
- Watchlist saved in browser localStorage
- Card scan page with front/back image upload preview
- Manual market/condition inputs
- Deal score calculation
- Responsive phone layout

## Important
This is DEMO MODE. It does not connect to live eBay data and does not guarantee grades or returns.

## Production architecture
1. Frontend: Next.js/React or similar.
2. Backend: server-side API routes; never put eBay secrets in browser code.
3. eBay: official Browse API for current listings/search and item details. eBay documents keyword/category/image search and item-detail retrieval.
4. Database/auth: Supabase is a practical early option.
5. AI: image analysis endpoint for listing photos, with conservative confidence and "needs manual review" states.
6. Payments: subscription provider after product-market fit.

## First production features
- eBay OAuth/app credentials
- Search current listings
- Normalize card title/year/set/player
- Store listing snapshots
- Price history from legally available/authorized data
- AI image analysis
- User watchlists and alerts
- BUY/WATCH/PASS explanations
- Subscription limits

## Recommended scoring
30% price vs raw market
20% player/card demand
20% centering
15% visible condition
10% PSA 10 upside
5% sales velocity

## Run it
Open index.html in a browser. No server is required for this demo.

For a production version, move API calls to a backend and use environment variables for credentials.
